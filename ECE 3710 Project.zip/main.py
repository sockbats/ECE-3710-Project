# Data retrieved from https://world-weather.info/forecast/usa/provo/
# and placed into "Provo Weather Data.csv"
import csv
import math
import random
import matplotlib.pyplot as plt


def main():
    temperatures = []
    with open("Provo Weather Data.csv", "r") as csvFile:
        f = csv.reader(csvFile)
        next(f)
        for row in f:
            temperatures.append(int(row[1]))

    temperatures.sort()
    length = len(temperatures)

    # Mean
    mean = sum(temperatures) / length

    # Median
    if length // 2 % 1 != 0:
        median = temperatures[length // 2] + temperatures[(length // 2) + 1] / 2
    else:
        median = temperatures[length // 2]

    # Sample Variance
    sample_variance = 0
    for i in temperatures:
        sample_variance += (i - mean) ** 2
    sample_variance /= (length - 1)

    # Standard Deviation
    standard_deviation = math.sqrt(sample_variance)

    # Simple Random Sample
    random.seed(0)
    random_sample = sorted(random.sample(temperatures, 20))
    random_mean = sum(random_sample) / len(random_sample)
    random_length = len(random_sample)

    # SRS Sample Variance
    random_sample_variance = 0
    for i in random_sample:
        random_sample_variance += (i - random_mean) ** 2
    random_sample_variance /= (random_length - 1)

    # SRS Standard Deviation
    random_standard_deviation = math.sqrt(random_sample_variance)

    # Trimmed Means
    trimmed_data = temperatures[length // 20:-length // 20]
    trimmed_mean_5 = sum(trimmed_data) / len(trimmed_data)
    trimmed_data = temperatures[length // 10:-length // 10]
    trimmed_mean_10 = sum(trimmed_data) / len(trimmed_data)
    trimmed_data = temperatures[length // 5:-length // 5]
    trimmed_mean_20 = sum(trimmed_data) / len(trimmed_data)

    # Quartiles
    if length // 4 % 1 != 0:
        first_quartile = temperatures[length // 4] + temperatures[(length // 4) + 1] / 2
        third_quartile = temperatures[(length // 4) * 3] + temperatures[((length // 4) * 3) + 1] / 2
    else:
        first_quartile = temperatures[length // 4]
        third_quartile = temperatures[(length // 4) * 3]

    # Mode
    frequency = {}
    for item in temperatures:
        if item not in frequency:
            frequency[item] = 1
        else:
            frequency[item] += 1
    mode = max(frequency, key=frequency.get)

    # Final Output
    output = f"01. Mean: {mean:.3f}; Median: {median}\n" \
             f"02. Sample Variance: {sample_variance:.3f}; Standard Deviation: {standard_deviation:.3f}\n" \
             f"03. Simple Random Sample: {random_sample}\n   " \
             f"SRS Mean: {random_mean}; " \
             f"SRS Sample Variance: {random_sample_variance:.3f}; " \
             f"SRS Standard Deviation: {random_standard_deviation:.3f}\n" \
             f"04. This random sample does properly represent the entire data. The mean is very similar" \
             f"And the variance is much lower, meaning it more accurately represents the data.\n" \
             f"05. Trimmed Means:\n   " \
             f"5%: {trimmed_mean_5:.3f}\n   " \
             f"10%: {trimmed_mean_10:.3f}\n   " \
             f"20%: {trimmed_mean_20:.3f}\n" \
             f"06. First Quartile: {first_quartile}; Third Quartile: {third_quartile}\n" \
             f"07. Mode: {mode}; Median: {median}; See Dot Plot.png\n" \
             f"08. See Histogram.png\n" \
             f"09. There is an outlier of 68º, which occured on March 27, 2022. See Box Plot.png\n" \
             f"10. Based on this data, the temperature during the first week of January " \
             f"would likely range between 30-50ºF, based on the mean of 40 and the standard deviation of 10"
    print(output)
    with open("Report.txt", "w") as f:
        f.write(output)
    dot_plot = {}
    x = []
    y = []
    for item in temperatures:
        if item not in dot_plot:
            dot_plot[item] = 1
            x.append(item)
            y.append(1)
        else:
            dot_plot[item] += 1
            x.append(item)
            y.append(dot_plot[item])
    plt.scatter(x, y)
    plt.title("Dot Plot of Temperatures in Provo (Jan-Mar 2022)")
    plt.xlabel("Temperature(°F)")
    plt.ylabel("Number of Occurences")
    plt.savefig("Dot Plot.png")
    plt.clf()
    plt.title("Histogram of Temperatures in Provo (Jan-Mar 2022)")
    plt.xlabel("Temperature(°F)")
    plt.ylabel("Number of Occurences")
    plt.hist(temperatures)
    plt.savefig("Histogram.png")
    plt.clf()
    plt.title("Box Plot of Temperatures in Provo (Jan-Mar 2022)")
    plt.xlabel("Temperature(°F)")
    plt.boxplot(temperatures, vert=False)
    plt.savefig("Box Plot.png")


if __name__ == '__main__':
    main()
